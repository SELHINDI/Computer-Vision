# intro-to-computer-vision

### Installation
Install python packages
   ```Shell
   pip install -r requirement.txt
   ```
# Hello, Thank you so much for your time and help.